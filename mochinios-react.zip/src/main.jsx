import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Clientes from './pages/clientes/index.jsx';
import DetalleCliente from './pages/clientes/detalle.jsx';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    <Routes>
      <Route path='/' element={<Clientes />} />
      <Route path='/clientes/:id' element={<DetalleCliente />} />
    </Routes>
  </BrowserRouter>
);