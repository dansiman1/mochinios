import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './clientes_styles.css';

const DetalleCliente = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const clientes = {
    1: { nombre: 'Andrea Romero', telefono: '555-1234', correo: 'andrea@correo.com' },
    2: { nombre: 'Carlos Méndez', telefono: '555-5678', correo: 'carlos@correo.com' },
    3: { nombre: 'Valeria López', telefono: '555-9012', correo: 'valeria@correo.com' }
  };

  const cliente = clientes[id];
  if (!cliente) return <p>Cliente no encontrado.</p>;

  return (
    <div className='detalle-cliente'>
      <h2>Detalle de Cliente</h2>
      <p><strong>Nombre:</strong> {cliente.nombre}</p>
      <p><strong>Teléfono:</strong> {cliente.telefono}</p>
      <p><strong>Correo:</strong> {cliente.correo}</p>
      <button onClick={() => navigate(-1)}>← Volver</button>
    </div>
  );
};

export default DetalleCliente;